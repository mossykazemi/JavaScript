console.log(test());



function test(){
    return "this is test.";
}
