class Car{
    constructor(brand){
        this._carname=brand;
    }
    set cname(x){
        this._carname=x;
    }
    get cname(){
        return this._carname;
    }
}
let testcar=new Car("L90");