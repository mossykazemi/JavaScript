// function test(){
//     return "test";
// }
// let message = test();
// console.log(message);


let test=function(){
    return "test"
}
console.log(test());