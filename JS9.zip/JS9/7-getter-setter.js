class Car{
    constructor(brand){
        this._carname=brand;
    }
    get cname(){
        return this._carname;
    }
    set cname(carn){
        this._carname=carn;
    }
}
mycar=new Car("L90");
mycar.cname="Ford";
// mycar.cname("BMW");
console.log(mycar.cname);