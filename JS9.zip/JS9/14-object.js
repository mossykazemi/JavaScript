var car1={
    make: 'Ford',
    model: 'mustang',
    year: 1969,
    details:{
        colors:['red','green','black'],
        wheel:4
    },
    run:function(){
        return "speed up yo 220";
    },
    summary:function(){
        return 'car details : '+this.model+ ' , '+ this.year;
    }

}

var car2={
    make: 'Ford',
    model: 'mustang',
    year: 1969,
    details:{
        colors:['red','green','black'],
        wheel:4
    },
    run:function(){
        return "speed up yo 220";
    },
    summary:function(){
        return 'car details : '+this.model+ ' , '+ this.year;
    }
}
// car1=car2;
// object ha yeki hastan ama harkodom yek object hastan va joda be khatere hamin false ro mibinim 
console.log(car1==car2);

