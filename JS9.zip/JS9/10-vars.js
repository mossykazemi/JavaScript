'strict'
var test=10;
var test=20;
console.log(test);