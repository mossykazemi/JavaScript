class test{
    constructor(test){
        this._message=test;
    }
    show(){
        return this._message;
    }
}
mytest=new test("tis is a test");
console.log(mytest.show());