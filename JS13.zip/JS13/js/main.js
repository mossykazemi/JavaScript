let membership={
    username:"mostafa",
    password:"123",
    set uname(value){
        this.username=value.toUpperCase();
    },
    get uname(){
        return this.username.toUpperCase();
    },
    set psw(value){
        this.password=value;
    },
    get psw(){
        return this.password;
    }

}
function login(){
    let uname=document.getElementById("username");
    let psw=document.getElementById("password");
    let result=document.getElementById("demo");
    
    if(membership.uname==uname.value.toUpperCase() && 
    membership.psw==psw.value){
        result.innerHTML="welcome";
    }else{
        result.innerHTML="try again!";
    }
}