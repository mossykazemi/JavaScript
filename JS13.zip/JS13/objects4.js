let membership={
    username:"",
    password:"",
    set uname(value){
        this.username=value.toUpperCase();
    },
    get uname(){
        return this.username;
    },
    set psw(value){
        this.password=value;
    },
    get psw(){
        return this.password;
    }

}
membership.uname="Mostafa";
console.log(membership.uname);

membership.psw="abcdsweq";
console.log(membership.psw);