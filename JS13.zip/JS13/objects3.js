let person={
    firstname:"Mostafa",
    lastname:"kazemi",
    language:"fa",
    set lang(value){
        this.language=value;
    },
    get lang(){
        return this.language;
    }
};
person.lang="en";
console.log(person.lang);