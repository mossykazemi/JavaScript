class Color{
    constructor(color, theme){
        this.ColorName=color;
        this.theme=theme;
    }
    present(x){
        return x+" color is :"+this.ColorName+"-"+this.theme;
    }
}
myColor= new Color("Blue" , "Metalic");
console.log(myColor.present("my favorite"));
