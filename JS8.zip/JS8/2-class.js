class Car{
    constructor(){
        this.carname="default";
    }
}
mycar=new Car();
console.log(mycar.carname);

// mySecondCar=new Car("Ford");