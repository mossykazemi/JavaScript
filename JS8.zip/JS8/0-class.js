class Car{
    constructor(brand){
        this.carname=brand;
    }
}
myCar=new Car("Ford");
console.log(myCar.carname);