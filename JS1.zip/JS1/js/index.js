// function setTime(){
    
//     var name=document.getElementById("fname").value;
//     document.getElementById("demo").innerHTML=Date();
// }


// alert('hi');