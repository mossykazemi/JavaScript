function searchMenu(){
    let input, filter, ul , li, a;
    input=document.getElementsByClassName("search")[0];
    filter=input.value.toUpperCase();
    ul=document.getElementsByClassName("menu")[0];
    li=ul.getElementsByTagName("li");
    for(i=0;i<li.length;i++){
        a=li[i].getElementsByTagName("a")[0];
        if(a.innerHTML.toUpperCase().indexOf(filter)>-1){
            // release
            li[i].style.display="block";
        }else{
            li[i].style.display="none";
        }
        
    }
}